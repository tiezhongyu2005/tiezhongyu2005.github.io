function [Best,delta] = update_delta(funfcn,Best,SE,Range,Omega)
Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);
m  = length(Omega);
fBest = feval(funfcn,Best);
delta = 1;
Best0 = Best;
for i = 1:m
    State = op_axes(Best0,SE,Omega(i)); %
    %Apply  for State > Pop_Ub or State < Pop_Lb
    changeRows = State > Pop_Ub;
    State(find(changeRows)) = Pop_Ub(find(changeRows));
    changeRows = State < Pop_Lb;
    State(find(changeRows)) = Pop_Lb(find(changeRows));
    %Apply  for State > Pop_Ub or State < Pop_Lb
    [tempBest,tempfBest] = fitness(funfcn,State);
    if tempfBest < fBest
        Best = tempBest;
        fBest = tempfBest;
        delta = Omega(i);
    end
end
