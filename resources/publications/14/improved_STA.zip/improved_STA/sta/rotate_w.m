function [Best,fBest] = rotate_w(funfcn,Best,SE,Range,Omega)
[Best,alpha] = update_alpha(funfcn,Best,SE,Range,Omega);
for i = 1:10
    [Best,fBest] = rotate(funfcn,Best,SE,Range,alpha);
end