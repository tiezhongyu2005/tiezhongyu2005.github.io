function [Best,fBest] = axesion_w(funfcn,Best,SE,Range,Omega)
[Best,delta] = update_delta(funfcn,Best,SE,Range,Omega);
for i = 1:10
    [Best,fBest] = axesion(funfcn,Best,SE,Range,delta);
end