function [Best,fBest,history] = STA(funfcn,SE,Dim,Range)

rand('state',sum(100*clock))
% 
State = initialization(SE,Dim,Range);
[Best,fBest] = fitness(funfcn,State);


Omega = [1,1e-1,1e-2,1e-3,1e-4,1e-5,1e-6,1e-7,1e-8];

% 
iter = 0;
counter = 0;
while(1)
    oldfBest = fBest;
    [Best,fBest] = expand_w(funfcn,Best,SE,Range,Omega);
    [Best,fBest] = rotate_w(funfcn,Best,SE,Range,Omega);
    [Best,fBest] = axesion_w(funfcn,Best,SE,Range,Omega);
    iter = iter + 1;
    %  termination conditions
    if norm(oldfBest-fBest) < 1e-8 % can be changed
        counter = counter + 1;
        if counter > 10 % can be changed
            break;
        end
    else
        counter = 0;
    end
    fprintf('iter=%d      ObjVal=%g\n',iter,fBest);
    history(iter) = fBest;




end



