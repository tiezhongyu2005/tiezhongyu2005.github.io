function [Best,fBest] = expand_w(funfcn,Best,SE,Range,Omega)
[Best,gamma] = update_gamma(funfcn,Best,SE,Range,Omega);
for i = 1:10
    [Best,fBest] = expand(funfcn,Best,SE,Range,gamma);

end
