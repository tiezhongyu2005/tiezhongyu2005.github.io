clear all
clc
currentFolder = pwd;
addpath(genpath(currentFolder))
% parameter setting
warning('off')
SE =  30; % degree of search enforcement
Dim = 100;% dimension
Range = repmat([-10*Dim;10*Dim],1,Dim);%range
tic
[Best,fBest,history] = STA(@quadconvex,SE,Dim,Range);
toc
semilogy(history)