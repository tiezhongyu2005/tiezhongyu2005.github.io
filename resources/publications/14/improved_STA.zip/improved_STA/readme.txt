This is a vector version of State Transition Algorithm
The main function is Test_sta.
You are suggested to cite the following references if you are using the basic STA.
1) X.J. Zhou, C.H. Yang and W.H. Gui, State Transition Algorithm, 
Journal of Industrial and Management Optimization 8(4): 1039-1056, 2012.
2) X.J. Zhou, C.H. Yang and W.H. Gui, Nonlinear system identification and control using
state transition algorithm, Applied Mathematics and Computation, 226: 169--179, 2014.
3) X. J. Zhou, D.Y. Gao, C.H. Yang, W.H. Gui, Discrete state transition algorithm for 
unconstrained integer optimization problems, Neurocomputing, 173: 864-874, 2016.
4) X. J. Zhou, D.Y. Gao, A.R. Simpson, Optimal design of water distribution networks 
by discrete state transition algorithm, Engineering Optimization, 48(4):603-628,2016.
5) J. Han, C.H. Yang, X.J. Zhou*, W.H. Gui, A new multi-threshold image segmentation approach
using state transition algorithm, Applied Mathematical Modelling, 44:588�C601,2017.
6) X. J. Zhou, P Shi, C C Lim, C.H. Yang, W.H. Gui, A dynamic state transition algorithm with 
application to sensor network localization, Neurocomputing, 273:237-250,2018.
7) F.X. Zhang, C.H. Yang, X.J. Zhou*, W.H. Gui, Fractional-order PID controller tuning using 
continuous state transition algorithm, Neural Computing and Applications, 29(10):795-804,2018.
8) J. Han, C.H. Yang, X.J. Zhou*, W.H. Gui, A two-stage state transition algorithm for constrained 
engineering optimization problems, International Journal of Control Automation and Systems, 16(2):522�C534, 2018.
9) M. Huang, X.J. Zhou*, T.W. Huang, C.H. Yang, W.H. Gui, Dynamic optimization based on state transition algorithm 
for copper removal process, Neural Computing and Applications, 2017, DOI: 10.1007/s00521-017-3232-0
10) Z.K. Huang, C.H. Yang, X.J. Zhou*, W.H. Gui, A novel cognitively-inspired state transition algorithm 
for solving the linear bi-level programming problem, Cognitive Computation, 2018, DOI: 10.1007/s12559-018-9561-1
11) X.J. Zhou, J.J. Zhou, C.H. Yang, W.H. Gui, Set-point tracking and multi-objective optimization-Based PID 
control for the goethite process, IEEE ACCESS, 6:36683-36698, 2018.
12) X.J. Zhou, C.H. Yang, W.H. Gui, A Statistical Study on Parameter Selection of Operators in Continuous State Transition Algorithm, 
IEEE Transactions on Cybernetics, 2018, DOI:10.1109/TCYB.2018.2850350


Contact Information��
Dr. Xiaojun Zhou
PhD
School of Information Science and Engineering
Central South University
Changsha, Hunan, P.R. China 
410083
michael.x.zhou@csu.edu.cn
+86-13787052648

The matlab codes are run under the Matlab 2010b. Please do not hesitate to contact me if you have any further questions.
