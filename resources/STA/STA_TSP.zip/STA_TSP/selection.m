function [Best,fBest] = selection(State,A)
[m,~] = size(State);
fvalue = zeros(m,1);
for i = 1:m
    fvalue(i) = distance(State(i,:),A);
end
[fBest,index] = min(fvalue);
Best = State(index,:);