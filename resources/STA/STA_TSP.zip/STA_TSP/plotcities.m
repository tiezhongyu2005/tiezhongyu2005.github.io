function plotcities(A,Best,iter)
B=A(:,2:3);
C=B(Best,:);
fBest = distance(Best,A);
%to a restricted range
x=C(:,1);
y=C(:,2);
xmin=min(x);
xmax=max(x);
ymin=min(y);
ymax=max(y);
shg
temp= line(x,y,'Marker','o');
set(temp,'color','b');
string = ['The roundtrip length for ', num2str(length(Best)-1), ' cities is ',...
    num2str(fBest), ' units using discrete STA'];
title(string);
xlabel(num2str(iter));
drawnow;