function State = initiation(SE,n)
%initiation
State = zeros(SE,n);
for i=1:SE
    State(i,:) = randperm(n);
end
