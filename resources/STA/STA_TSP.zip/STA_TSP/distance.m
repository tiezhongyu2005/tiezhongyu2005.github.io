function Dist = distance(indiv,A)
indiv = [indiv,indiv(1)];
n1 = length(indiv);
Dist = 0;
for i=1:n1-1
    Dist = Dist + norm(A(indiv(i),2:end)-A(indiv(i+1),2:end));
end
