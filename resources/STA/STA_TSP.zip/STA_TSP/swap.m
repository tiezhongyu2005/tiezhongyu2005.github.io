function [Best,fBest] = swap(A,Best,fBest,SE,n)
State = op_swap(Best,SE);
newState = zeros(SE*SE/2,n);
for i = 1:SE/2
    newState((i-1)*SE+1:i*SE,:) = op_swap(State(i,:),SE);
end
[newBest,fnewBest] = selection([State;newState],A);
if fnewBest < fBest
    Best = newBest;
    fBest = fnewBest;
end