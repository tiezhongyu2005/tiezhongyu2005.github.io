function State = op_symmetry(Best,SE)
n = length(Best);
State = zeros(SE,n);
for i = 1:SE
    temp = Best;
    R = randperm(n);
    a = R(1);
    b = R(2);
    if a < b
        temp(a:b) = Best(b:-1:a);
    else
        temp(b:a) = Best(a:-1:b);
    end
    State(i,:) = temp;
end