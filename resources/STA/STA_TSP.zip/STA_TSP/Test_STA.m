clear all
clc
SE = 30;
MaxIter = 2e2;
[Dimension,NodeCoord,NodeWeight,Name] = GetTSPData('berlin52.tsp');
A = NodeCoord;
[n,~] = size(A);
tic

[Best,fBest,history] = TSP_STA(A,SE,n,MaxIter);
Best
fBest
toc
plotcities(A,[Best,Best(1)],MaxIter);


