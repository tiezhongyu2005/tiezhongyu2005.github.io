function State = op_shift(Best,SE)
n = length(Best);
State = zeros(SE,n);
for i = 1:SE
    temp = Best;
    R = randperm(n);
    a = R(1);
    b = R(2);
    if a < b  
        temp(a:b) = temp([a+1:b,a]);
    else
        temp(b:a) = temp([b+1:a,b]);
    end
    State(i,:) = temp;
end