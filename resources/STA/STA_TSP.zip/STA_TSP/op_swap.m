function State = op_swap(Best,SE)
n = length(Best);
State = zeros(SE,n);
for i = 1:SE
    temp = Best;
    R = randperm(n);
    T  = R(1:2);
    S = fliplr(T);
    temp(T) = temp(S);
    State(i,:) = temp;
end