function [Best,fBest,history] = TSP_STA(A,SE,n,Interations)
% initiation
State = initiation(SE,n);
[Best,fBest] = selection(State,A);
history = zeros(Interations,1);
% iterations
for iter =1:Interations
    [Best,fBest] = swap(A,Best,fBest,SE,n);
    [Best,fBest] = shift(A,Best,fBest,SE,n);
    [Best,fBest] = symmetry(A,Best,fBest,SE,n);
     plotcities(A,[Best,Best(1)],iter), hold on
     clf
% Best
    history(iter) = fBest;
end