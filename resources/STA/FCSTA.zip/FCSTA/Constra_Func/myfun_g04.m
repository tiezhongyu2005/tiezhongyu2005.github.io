function y = myfun_g04(x)
% global count 
% count = count + 1;

% fitness function
y = 5.3578547*x(:,3).^2+0.8356891*x(:,1).*x(:,5)+37.293239*x(:,1)-40792.141 ;
