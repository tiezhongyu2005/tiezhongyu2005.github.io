function y = myfun_g22(x)
% global count 
% count = count + 1;

y=x(:,1);