function y = myfun_g15(x)
% global count 
% count = count + 1;

y=1000-x(:,1).^2-2*x(:,2).^2-x(:,3).^2-x(:,1).*x(:,2)-x(:,1).*x(:,3);