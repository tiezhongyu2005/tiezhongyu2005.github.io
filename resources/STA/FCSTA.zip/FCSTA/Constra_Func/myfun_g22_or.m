function y = myfun_g22_or(x)
% global count 
% count = count + 1;

y = x(:,1);