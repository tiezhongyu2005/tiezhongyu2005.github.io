function y = myfun_g13_or(x)
% global count 
% count = count + 1;

y = exp(x(:,1).*x(:,2).*x(:,3).*x(:,4).*x(:,5)) ;
