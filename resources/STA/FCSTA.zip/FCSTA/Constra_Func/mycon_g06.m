function [c,ceq] = mycon_g06(x)

% constraints g<=0
c(:,1) = -(x(:,1)-5).^2 - (x(:,2)-5).^2 + 100 ;
c(:,2) = (x(:,1)-6).^2 + (x(:,2)-5).^2 - 82.81 ;

ceq = [];