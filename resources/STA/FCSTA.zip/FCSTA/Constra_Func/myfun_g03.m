function y = myfun_g03(x)
% global count 
% count = count + 1;

n = size(x,2) ;
y = -(sqrt(n))^n*prod(x,2) ;