function f = myfun_g14_or(x)
% global count 
% count = count + 1;

[~,n]=size(x);
f=0;
C=[-6.089 -17.164 -34.054 -5.914 -24.721 -14.986 -24.1 -10.708 -26.662 -22.179];
for i=1:n
    f=f+x(:,i)*C(i)+x(:,i).*log(x(:,i)./sum(x,2));
end