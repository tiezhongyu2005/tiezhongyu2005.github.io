function f = myfun_g10(x)
% global count 
% count = count + 1;

f = sum(x(:,1:3),2) ;

