function f = myfun_g18(x)
% global count 
% count = count + 1;

f=-0.5*(x(:,1).*x(:,4)-x(:,2).*x(:,3)+x(:,3).*x(:,9)-x(:,5).*x(:,9)+x(:,5).*x(:,8)-x(:,6).*x(:,7));
