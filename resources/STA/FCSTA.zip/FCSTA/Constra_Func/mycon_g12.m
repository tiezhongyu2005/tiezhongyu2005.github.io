function [c,ceq] = mycon_g12(x)

% constraints
% p = [1 3 5 7 9] ;
p = 1:9 ;
q = p ;
r = q ;
l = 1 ;
for i=1:length(p),
  for j=1:length(q), 
    for k=1:length(r),
      c(:,l) = (x(:,1)-p(i)).^2+(x(:,2)-q(j)).^2+(x(:,3)-r(k)).^2 - 0.0625 ;
      l = l+1 ;
    end
  end
end
c = min(c,[],2) ;

ceq = [];