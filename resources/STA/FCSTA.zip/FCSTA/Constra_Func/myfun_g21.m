function y = myfun_g21(x)
% global count 
% count = count + 1;

y = x(:,1);