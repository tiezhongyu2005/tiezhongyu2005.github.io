function y = myfun_g08(x)
% global count 
% count = count + 1;

% fitness functions
y = -((sin(2*pi*x(:,1)).^3).*sin(2*pi*x(:,2)))./((x(:,1).^3).*(x(:,1)+x(:,2))+eps) ;
