function [c,ceq] = mycon_g03(x)

c= [ ];
ceq = sum(x.^2,2) - 1;
