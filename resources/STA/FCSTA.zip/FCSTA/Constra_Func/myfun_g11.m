function y = myfun_g11(x)
% global count 
% count = count + 1;

% fitness function
y = x(:,1).^2+(x(:,2)-1).^2 ;