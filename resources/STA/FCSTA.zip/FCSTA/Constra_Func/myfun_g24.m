function y = myfun_g24(x)
% global count 
% count = count + 1;

y = -x(:,1)-x(:,2);