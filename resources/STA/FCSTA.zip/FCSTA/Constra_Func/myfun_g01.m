function y = myfun_g01(x)
% global count 
% count = count + 1;
% fitness function
y = 5*sum(x(:,1:4),2) - 5*sum((x(:,1:4).^2),2) - sum(x(:,5:13),2) ;
