function y = myfun_g05_or(x)
% global count 
% count = count + 1;

y = 3*x(:,1) + 0.000001*x(:,1).^3 + 2*x(:,2) + (0.000002/3).*(x(:,2).^3) ;