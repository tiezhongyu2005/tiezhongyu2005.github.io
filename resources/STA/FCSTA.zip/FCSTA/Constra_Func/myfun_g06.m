function y = myfun_g06(x)
% global count 
% count = count + 1;

% fitness function
y = (x(:,1)-10).^3+(x(:,2)-20).^3 ;