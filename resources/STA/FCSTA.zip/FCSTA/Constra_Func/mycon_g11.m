function [c,ceq] = mycon_g11(x)

delta = 0.0001 ; % tolerated equality constraint violation

% constraint h=0 => g=|h|-delta<=0
c(:,1) = abs(x(:,2) - x(:,1).^2) - delta ;

ceq = [];
