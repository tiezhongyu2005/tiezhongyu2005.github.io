function [c,ceq] = mycon_g02(x)
c(:,1) = 0.75-prod(x,2);
c(:,2) = sum(x')'-7.5*size(x,2);
ceq = [];
    
