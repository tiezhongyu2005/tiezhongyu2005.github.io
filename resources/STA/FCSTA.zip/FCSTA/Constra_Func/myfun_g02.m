function y = myfun_g02(x)
% global count 
% count = count + 1;

y = -abs(sum((cos(x).^4),2) - 2*prod((cos(x).^2),2))./...
    sqrt(sum(((ones(size(x,1),1)*[1:size(x,2)]).*(x.^2)),2)) ;