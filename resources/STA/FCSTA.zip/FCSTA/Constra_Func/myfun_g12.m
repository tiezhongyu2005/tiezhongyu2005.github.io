function y = myfun_g12(x)
% global count 
% count = count + 1;

% objective function
y = -(100-(x(:,1)-5).^2-(x(:,2)-5).^2-(x(:,3)-5).^2)/100 ;
