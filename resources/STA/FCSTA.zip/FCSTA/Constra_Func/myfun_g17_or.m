function y = myfun_g17_or(x)
% global count 
% count = count + 1;

[n,~] = size(x);
if zeros(n,1) <= x(:,1) < 300*ones(n,1)
    y(:,1) = 30*x(:,1);
else
    y(:,1) = 31*x(:,1);
end

if zeros(n,1) <= x(:,2) < 100*ones(n,1)
    y(:,2) = 28*x(:,2);
else if  100*ones(n,1) <= x(:,2) < 200*ones(n,1)
         y(:,2) = 29*x(:,2);
     else    
         y(:,2) = 30*x(:,2);
    end
end
y = y(:,1)+y(:,2);