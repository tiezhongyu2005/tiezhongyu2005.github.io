function y = myfun_g14(x)
% global count 
% count = count + 1;

[~,n]=size(x);
C=[-17.164 -34.054 -24.721 -14.986 -24.1 -26.662 -22.179];

t1 = 2 - 2*x(:,1) - 2*x(:,2) - x(:,4) - x(:,7);
t4 = 1 - 2*x(:,3) - x(:,4) - x(:,5);
t8 = 1 - x(:,2) - x(:,5) - 2*x(:,6) - x(:,7);

index1 = find(t1 < 0);
t1_1 = t1;
t1_1(index1,:) = x(index1,1);

index4 = find(t4 < 0);
t4_4 = t4;
t4_4(index4,:) = x(index4,1);

index8 = find(t8 < 0);
t8_8 = t8;
t8_8(index8,:) = x(index8,1);

total = sum(x,2) + t1_1 + t4_4 + t8_8;
y = t1_1*(-6.089)+t1_1.*log(t1_1./total) + t4_4*(-5.914)+t4_4.*log(t4_4./total) + t8_8*(-10.708)+t8_8.*log(t8_8./total);
for i=1:n
    y=y+x(:,i)*C(i)+x(:,i).*log(x(:,i)./sum(x,2));
end