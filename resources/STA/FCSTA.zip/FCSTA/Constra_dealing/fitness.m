function fit = fitness(objective_fun,constraint_fun,x)
global count
m = size(x,1);
count = count + m;
f = feval(objective_fun,x);
g = feval(constraint_fun,x);
fit(:,1) = f;%Ŀ�꺯��ֵ
fit(:,2) = sum(max(0,g),2);%Լ��Υ����