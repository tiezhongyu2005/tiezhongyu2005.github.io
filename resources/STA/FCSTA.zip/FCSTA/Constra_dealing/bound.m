function State = bound(State,Range)
SE = size(State,1);
Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);

% �߽�
% changeRows = State > Pop_Ub;
% State(changeRows) = Pop_Ub(changeRows);
% changeRows = State < Pop_Lb;
% State(changeRows) = Pop_Lb(changeRows);

%�ڲ�
changeRows = State > Pop_Ub;
State(changeRows) = Pop_Ub(changeRows) - rand(length(find(changeRows)),1).*(Pop_Ub(changeRows)-Pop_Lb(changeRows));
changeRows = State < Pop_Lb;
State(changeRows) = Pop_Lb(changeRows) + rand(length(find(changeRows)),1).*(Pop_Ub(changeRows)-Pop_Lb(changeRows));







