function  State = initialization(SE,Range)
Pop_Lb = Range(1,:);
Pop_Ub = Range(2,:);
State  = rand(SE,length(Pop_Lb)).*repmat(Pop_Ub - Pop_Lb,SE,1) + repmat(Pop_Lb,SE,1);
