function y = op_rotate(Best,SE,alpha)
%��ת����
% n = length(Best);
% y = repmat(Best',1,SE) + alpha*(1/n/(norm(Best)+eps))*reshape(unifrnd(-1,1,SE*n,n)*Best',n,SE);
% y = y';
n = length(Best);
R1 = 2*rand(SE,n)-1;
R2 = 2*rand(SE,1)-1;
y = repmat(Best,SE,1) + alpha*repmat(R2,1,n).*R1./repmat(sqrt(sum(R1.*R1,2)),1,n);
