function [x,f,g] = FCSTA(objective_fun,constraint_fun,Range)
global  sel_feasi_num sel_infeasi_num count  % ȷ���������п��н��벻���н�ĸ���
sel_feasi_num = 4;
sel_infeasi_num = 4;    
count = 0;

FES = 299850;
%
options = optimoptions(@fmincon,'Display','off', 'MaxFunctionEvaluations', 150, ...
    'Algorithm','sqp','ConstraintTolerance',0,'StepTolerance',0,'OptimalityTolerance',0);
% options.Algorithm = 'interior-point';

x_archive = STA(objective_fun,constraint_fun,Range,FES);
N = size(x_archive,1);
[x,f] = fmincon(objective_fun,x_archive(1,:),[],[],[],[],Range(1,:),Range(2,:),constraint_fun,options);
g = feval(constraint_fun,x);
for i = 2:N
    [xt,ft] = fmincon(objective_fun,x_archive(1,:),[],[],[],[],Range(1,:),Range(2,:),constraint_fun,options);
    gt = feval(constraint_fun,x);
    if sum(max(0,gt),2) <= sum(max(0,g),2) && ft < f
        x = xt;
        f = ft;
        g = gt;
    end
end
    