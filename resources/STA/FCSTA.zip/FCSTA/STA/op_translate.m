function y = op_translate(oldBest,newBest,SE,beta)
% translation
y = repmat(newBest,SE,1) + beta*randn(SE,length(oldBest)).*repmat(newBest-oldBest,SE,1);


