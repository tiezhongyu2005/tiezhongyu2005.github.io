function [new_x_archive,new_fit_archive] = rotate(objective_fun,constraint_fun,x_archive,fit_archive,SE,Range,alpha)

[n,~] = size(x_archive);
for i = 1:n
    x((i-1)*SE+1:i*SE,:) = op_rotate(x_archive(i,:),SE,alpha); %rotation operator
end
%Apply  for State > Pop_Ub or State < Pop_Lb
x = bound(x,Range);
fit = fitness(objective_fun,constraint_fun,x);
x = [x_archive;x];
fit = [fit_archive;fit];
[new_x_archive,new_fit_archive] = selection_strategy(x,fit);







