function [x_archive,fit_archive] = STA(objective_fun,constraint_fun,Range,FES)

global count

% parameter settings
alpha = 1;
beta = 1;
gamma = 1;
delta = 1;

fc = 2;
SE = 3e1;

% initialization
rand('state',sum(100*clock));
x = initialization(SE,Range);
fit = fitness(objective_fun,constraint_fun,x);
[x_archive,fit_archive] = selection_strategy(x,fit);

%--------------------------------------------------------------------------
while count < FES
%    tic

    if alpha < 1e-4
        alpha = 1;
    end
        
    %  ���Ӳ�����ѡ��  

    [x_archive,fit_archive] = rotate(objective_fun,constraint_fun,x_archive,fit_archive,SE,Range,alpha);
    
    [x_archive,fit_archive] = expand(objective_fun,constraint_fun,x_archive,fit_archive,SE,Range,gamma);
    
    [x_archive,fit_archive] = axesion(objective_fun,constraint_fun,x_archive,fit_archive,SE,Range,delta);

    [x_archive,fit_archive] = translation(objective_fun,constraint_fun,x_archive,fit_archive,SE,Range,beta);

    alpha = alpha/fc;

     

end






