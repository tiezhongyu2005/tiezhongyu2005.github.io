function [new_x_archive,new_fit_archive] = translation(objective_fun,constraint_fun,x_archive,fit_archive,SE,Range,beta)

[n,~] = size(x_archive);
for i = 1:n

    R = randperm(n,1);
    x_R = x_archive(R,:);
    x((i-1)*SE+1:i*SE,:) = op_translate(x_R,x_archive(i,:),SE,beta); %translation operator
end
%Apply  for State > Pop_Ub or State < Pop_Lb
x = bound(x,Range);
fit = fitness(objective_fun,constraint_fun,x);
x = [x_archive;x];
fit = [fit_archive;fit];
[new_x_archive,new_fit_archive] = selection_strategy(x,fit);





