function obj = ZDT2(x)
obj = zeros(1,2);
D = length(x);
y = x(2:end);
gx = 1+9*sum(y)/(D-1);
obj(1) = x(1);
obj(2) = gx*(1-(x(1)/gx)^2);