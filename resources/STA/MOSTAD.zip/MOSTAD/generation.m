function[newState,fnewState] = generation(fun,State,Range,T,SE,alpha,gamma,delta)
N = size(State,1);
solution_index = randperm(N);  
oldState = State(solution_index(1:T),:);
newState = [];
for i = 1:T
    tempState = op_rotate(oldState(i,:),SE,alpha);
    newState = [newState;tempState];
    tempState = op_expand(oldState(i,:),SE,gamma);
    newState = [newState;tempState];
    tempState = op_axes(oldState(i,:),SE,delta);
    newState = [newState;tempState];
end
index = randperm(size(newState,1)); 
newState = bound(newState(index(1:N),:),Range);
fnewState = fitness(fun,newState);
