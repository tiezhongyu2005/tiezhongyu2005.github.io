function y = fitness(fun, x)
N = size(x,1); % N*D
for i = 1:N
y(i,:) = feval(fun, x(i,:));
end