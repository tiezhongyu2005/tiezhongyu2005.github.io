function lamda = generate_weight_vector(N)
lamda(1,:) = linspace(0,1,N);
lamda(2,:) = 1 - lamda(1,:);
lamda = lamda';