function scalarfit  = modiFit(fit,i,z,lamda)
for j = 1:length(lamda(i,:))
    if lamda(i,j)==0
       lamda(i,j) = eps; 
    end
end
varphi =  abs(abs((1./lamda(i,:)* (fit-z)'/( norm(1./lamda(i,:))* norm(fit-z))))-1);
scalarfit = max(lamda(i,:).*abs(fit - z)) +  max(lamda(i,:).*abs(fit - z))*varphi;
end
    