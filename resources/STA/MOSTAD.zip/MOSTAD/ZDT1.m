function obj = ZDT1(x)
obj = zeros(1,2);
D = length(x);
gx = 1+9*sum(x(2:end))/(D-1);
obj(1) = x(1);
obj(2) = gx*(1-sqrt(x(1)/gx));