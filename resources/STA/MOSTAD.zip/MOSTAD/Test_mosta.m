clear all
clc
currentFolder = pwd;
addpath(genpath(currentFolder))
warning('off')
N =  200; % ��Ⱥ��ģ
Dim = 30;% ά��
fun = 'ZDT2';
Range = repmat([0;1],1,Dim);%range
maxiter = 2e2;
tic
[State,fState] = MOSTAD(fun,Range,N,maxiter);
toc
draw(fun,fState)
