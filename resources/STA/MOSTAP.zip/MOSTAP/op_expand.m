function y = op_expand(Best,SE,gamma)
%
n = length(Best);
y = repmat(Best',1,SE) + gamma*(normrnd(0,1,n,SE).*repmat(Best',1,SE));
y = y';