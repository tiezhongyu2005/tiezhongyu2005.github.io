function State = bound(State,Range)
SE = size(State,1);
Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);
%Apply  for State > Pop_Ub or State < Pop_Lb
changeRows = State > Pop_Ub;
State(find(changeRows)) = Pop_Ub(find(changeRows));
changeRows = State < Pop_Lb;
State(find(changeRows)) = Pop_Lb(find(changeRows));
%Apply  for State > Pop_Ub or State < Pop_Lb