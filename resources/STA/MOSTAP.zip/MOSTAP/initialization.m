function  State = initialization(SE,Range)
Pop_Lb = Range(1,:);
Pop_Ub = Range(2,:);
Dim = length(Pop_Lb);
State  = rand(SE,Dim).*repmat(Pop_Ub-Pop_Lb,SE,1)+repmat(Pop_Lb,SE,1);
