function DistanceValue = crowding_distance(FunctionValue,FrontValue)


    [N,M] = size(FunctionValue);
    
    DistanceValue = zeros(1,N);                             % the crowding-distance of each solution
    front         = setdiff(unique(FrontValue),inf);        % the possible front numbers 
    for f = front
        NowFront = find(FrontValue==f);                     % all the solutions in front 'f'
        Fmax     = max(FunctionValue(NowFront,:),[],1);     % the maximum values of each objective of the solutions in 'f'
        Fmin     = min(FunctionValue(NowFront,:),[],1);     % the mininum values of each objective of the solutions in 'f'
        for i = 1 : M
            [~,rank] = sortrows(FunctionValue(NowFront,i)); % sort the solutions in 'f' in ascending order according to the i-th objective value
            % calculate the crowding-distance value of each solution in
            % 'f' on the i-th objective
            DistanceValue(NowFront(rank(1)))   = inf;
            DistanceValue(NowFront(rank(end))) = inf;
            for j = 2 : length(NowFront)-1
                DistanceValue(NowFront(rank(j)))=DistanceValue(NowFront(rank(j))) + (FunctionValue(NowFront(rank(j+1)),i)-FunctionValue(NowFront(rank(j-1)),i))/(Fmax(i)-Fmin(i));
            end
        end
    end
end

