function [State,fState] = generation(fun,State,fState,FrontState,Range,T,SE,alpha,gamma,delta)
N = size(State,1);
index = union(find(FrontState==1),find(FrontState==2));
if length(index)> T
    initial_Solution = State(index(1:T),:);
else
    initial_Solution = State(index,:);
end

newState = [];
for i = 1:size(initial_Solution,1)
    tempState = op_rotate(initial_Solution(i,:),SE,alpha);
    newState = [newState;tempState];
    tempState = op_expand(initial_Solution(i,:),SE,gamma);
    newState = [newState;tempState];
    tempState = op_axes(initial_Solution(i,:),SE,delta);
    newState = [newState;tempState];
end
newState = bound(newState,Range);
fnewState = fitness(fun,newState);
sum_fnewState = sum(fnewState,2);
[~,index] = sort(sum_fnewState);
if size(newState,1) > N
    tempState = newState(index(1:N),:);
    tempfState = fnewState(index(1:N),:);
    State = [State;tempState];
    fState = [fState;tempfState];
else
    State = [State;newState];
    fState = [fState;fnewState];
end


    