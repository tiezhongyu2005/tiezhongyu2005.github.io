function [Population,FunctionValue,FrontValue] = selection(fun,Population,FunctionValue,N)
[FrontValue,NoF] = ENS_SS(FunctionValue,'half');          	% non-dominated sort, and return the front number of each solution
DistanceValue    = crowding_distance(FunctionValue,FrontValue);    % calculate the crowding-distance values
% choose the solutions in the first several fronts     
NextPopulation   = zeros(1,N);                              % store the locations of solutions in 'Population' for the next population
NoNP             = numel(FrontValue,FrontValue<NoF);     	% the total number of solutions in the first several fronts
NextPopulation(1:NoNP)   = find(FrontValue<NoF);            % store the solutions in the first several fronts
        
% choose the solutions in the last front (solutions in the fronts before this front will be selected for next population,
% and the solutions in this front will be partially selected)
LastFront        = find(FrontValue==NoF);                   % the solutions in the last front
[~,rank]         = sort(DistanceValue(LastFront),'descend');% sort these solutions according to their crowding-distance values
NextPopulation(NoNP+1:N) = LastFront(rank(1:N-NoNP));       % store the solutions with larger crowding-distance values
% next population
Population       = Population(NextPopulation,:);    
% next population
FrontValue       = FrontValue(NextPopulation);              % the front number of each solution in the next population
FunctionValue    = fitness(fun,Population); 
